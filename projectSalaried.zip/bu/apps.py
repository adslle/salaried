from django.apps import AppConfig


class BuConfig(AppConfig):
    name = 'bu'
