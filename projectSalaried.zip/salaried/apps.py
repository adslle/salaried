from django.apps import AppConfig


class SalariedConfig(AppConfig):
    name = 'salaried'
